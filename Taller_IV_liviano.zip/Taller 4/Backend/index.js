const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.send('Servidor Express funcionando');
});

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    mensaje: 'La API está funcionando correctamente'
  });
});

app.get('/api/info', (req, res) => {
  res.json({
    integrantes: [
      {
        carnet: '00374124',
        ciudad: 'San Salvador',
        carrera: 'Ingenieria en Informatica',
        proyectosRealizados: 2
      },
      {
        carnet: '00142724',
        ciudad: 'San Salvador',
        carrera: 'Ingenieria en Informatica',
        proyectosRealizados: 4
      }
    ]
  });
});

app.listen(PORT, () => {
  console.log(`Servidor funcionando en http://localhost:${PORT}`);
});