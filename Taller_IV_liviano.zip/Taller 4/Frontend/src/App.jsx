
import { useState } from 'react';
import {
  Container,
  Button,
  Alert,
  Card,
  CardBody,
  CardTitle,
  CardText,
  Row,
  Col
} from 'reactstrap';

function App() {
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState(false);
  const [integrantes, setIntegrantes] = useState([]);

  // Consultar el estado de la API
  const verificarAPI = async () => {
    try {
      const respuesta = await fetch('http://localhost:3000/api/health');

      if (!respuesta.ok) {
        throw new Error('Error al consultar la API');
      }

      const datos = await respuesta.json();
      setMensaje(datos.mensaje);
      setError(false);
    } catch {
      setMensaje('No se pudo conectar con la API');
      setError(true);
    }
  };

  // Consultar los integrantes
  const obtenerIntegrantes = async () => {
    try {
      const respuesta = await fetch('http://localhost:3000/api/info');

      if (!respuesta.ok) {
        throw new Error('Error al consultar integrantes');
      }

      const datos = await respuesta.json();
      setIntegrantes(datos.integrantes);
    } catch {
      alert('No se pudo obtener la información de los integrantes');
    }
  };

  return (
    <Container className="text-center mt-5">
      <section>
        <h1>Taller IV</h1>
        <p>Programación Web - React y Express</p>

        <Button color="primary" onClick={verificarAPI} className="me-2">
          Verificar API
        </Button>

        <Button color="success" onClick={obtenerIntegrantes}>
          Mostrar integrantes
        </Button>

        {mensaje && (
          <div className="mt-4">
            <h4>Estado de la API</h4>
            <Alert color={error ? 'danger' : 'success'}>
              <p className="mb-0">{mensaje}</p>
            </Alert>
          </div>
        )}

        {integrantes.length > 0 && (
          <div className="mt-5">
            <h4>Información de los integrantes</h4>

            <Row className="mt-3">
              {integrantes.map((integrante, index) => (
                <Col md="6" key={integrante.carnet || index} className="mb-3">
                  <Card className="h-100 shadow-sm">
                    <CardBody>
                      <CardTitle tag="h5">
                        Integrante {index + 1}
                      </CardTitle>

                      <CardText>
                        <strong>Carnet:</strong> {integrante.carnet}
                      </CardText>

                      <CardText>
                        <strong>Ciudad de origen:</strong> {integrante.ciudad}
                      </CardText>

                      <CardText>
                        <strong>Carrera:</strong> {integrante.carrera}
                      </CardText>

                      <CardText>
                        <strong>Proyectos realizados:</strong>{' '}
                        {integrante.proyectosRealizados}
                      </CardText>
                    </CardBody>
                  </Card>
                </Col>
              ))}
            </Row>
          </div>
        )}
      </section>
    </Container>
  );
}

export default App;
